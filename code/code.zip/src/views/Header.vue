<template>
  <header>头部组件</header>
</template>

<script>
export default {
  name: "header"
};
</script>