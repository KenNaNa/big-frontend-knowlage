<template>
<div>
    <modal-button></modal-button>
</div>
</template>

<script>
import modalButton from './modalButton'
export default {
    name: 'tele',
    components: {
        modalButton
    }
}
</script>
