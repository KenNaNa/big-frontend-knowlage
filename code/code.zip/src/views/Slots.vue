<template>
  <div class="slot">
    <h2>子元素</h2>
    <slot>插槽默认内容</slot>
  </div>
</template>

<script>
export default {
  name: "slots"
};
</script>