<template>
  <div class="footer">页脚组件</div>
</template>

<script>
export default {
  name: "footer"
};
</script>