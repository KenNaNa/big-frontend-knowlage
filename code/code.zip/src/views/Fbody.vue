<template>
    <div class="body">
        中间内容
    </div>
</template>

<script>
export default {
    name: 'ftbody'
}
</script>