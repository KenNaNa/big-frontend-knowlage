<template>
  <div class="child">
    <h2>子元素</h2>
  </div>
</template>

<script>
export default {
  name: "child"
};
</script>